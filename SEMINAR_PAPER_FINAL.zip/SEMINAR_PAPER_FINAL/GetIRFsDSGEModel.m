function IRFs=GetIRFsDSGEModel(F,A0,H,Horizon);
NumberOfObservables=size(H,2);
[N,K]=size(A0);
%
IRFs=zeros(1+Horizon,NumberOfObservables);
Shock=1;
while Shock<=K
    % Pre-allocating the space for the IRF of the state vector S(t):
    S=zeros(N,1+Horizon);
    % The vector of shocks at t=0, u(0):
    Shocks=zeros(K,1);
    Shocks(Shock)=1;
    % The IRF of the state vector at t=0:
    S(:,1)=A0*Shocks;
    % The IRF of the state vector at t>0:
    for tt=2:1+Horizon
        S(:,tt)=F*S(:,tt-1);
    end
    % The IRF of the observed variables:
    IRFs(:,:,Shock)=(H'*S)';
    Shock=Shock+1;
end








