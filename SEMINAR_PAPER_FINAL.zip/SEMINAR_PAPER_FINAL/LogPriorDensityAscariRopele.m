function LPD=LogPriorDensityAscariRopele(x,A,B,NoLog)
if nargin<4
    NoLog='N';
end
x=x(:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A_SR=A(1);
A_Spi=A(2);
A_Sy=A(3);
A_Alpha=A(4);
A_Theta_1=A(5);
A_Sigma=A(6);
A_Rho=A(7);
A_Phi_pi=A(8);
A_Phi_y=A(9);
A_Rhos=A(10);
A_Epsi=A(11);
A_Gamma=A(12);
%
B_SR=B(1);
B_Spi=B(2);
B_Sy=B(3);
B_Alpha=B(4);
B_Theta_1=B(5);
B_Sigma=B(6);
B_Rho=B(7);
B_Phi_pi=B(8);
B_Phi_y=B(9);
B_Rhos=B(10);
B_Epsi=B(11);
B_Gamma=B(12);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_R=x(1);
S_pi=x(2);
S_y=x(3);
ThetaMinus1=x(4);
Alpha=x(5);
Epsi=x(6);
Sigma=x(7);
Gamma=x(8);
Rho=x(9);
Phi_pi=x(10);
Phi_y=x(11);
Rho_R=x(12);
Rho_y=x(13);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p_SR=InvGammaPDF(S_R,A_SR,B_SR); % S_R: InverseGamma, domain: R+
p_Spi=InvGammaPDF(S_pi,A_Spi,B_Spi); % S_u: InverseGamma, domain: R+
p_Sy=InvGammaPDF(S_y,A_Sy,B_Sy); % S_v: InverseGamma, domain: R+
p_ThetaMinus1=gampdf(ThetaMinus1,A_Theta_1,B_Theta_1); % phi: Gamma, domain: R+
p_Alpha=betapdf(Alpha,A_Alpha,B_Alpha); % rho: Beta, domain: [0 1)
p_Epsi=betapdf(Epsi,A_Epsi,B_Epsi); % rho: Beta, domain: [0 1)
p_Sigma=gampdf(Sigma,A_Sigma,B_Sigma); % sigma: Gamma, domain: R+
p_Gamma=betapdf(Gamma,A_Gamma,B_Gamma); % rho: Beta, domain: [0 1)
p_Rho=betapdf(Rho,A_Rho,B_Rho); % rho: Beta, domain: [0 1)
p_Phi_pi=gampdf(Phi_pi,A_Phi_pi,B_Phi_pi); % Phi_pi: Gamma, domain: R+
p_Phi_y=gampdf(Phi_y,A_Phi_y,B_Phi_y); % Phi_y: Gamma, domain: R+
p_Rho_R=betapdf(Rho_R,A_Rhos,B_Rhos); % rho_R: Beta, domain: [0 1)
p_Rho_y=betapdf(Rho_y,A_Rhos,B_Rhos); % rho_v: Beta, domain: [0 1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
LPD=p_SR*p_Spi*p_Sy*p_ThetaMinus1*p_Alpha*p_Epsi*p_Sigma*p_Gamma*p_Rho*p_Phi_pi*p_Phi_y*p_Rho_R*p_Rho_y*p_Epsi*p_Gamma;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if NoLog=='N' 
    % This is the log of the prior density:
    LPD=-log(LPD);
else
    % This is just the prior density itself:
    LPD=LPD;
end


    



    

    


