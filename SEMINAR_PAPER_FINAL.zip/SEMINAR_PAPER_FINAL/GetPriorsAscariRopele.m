function [A,B]=GetPriorsAscariRopele(Trend);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% S_R: Inverse Gamma, domain: R+
[A_SR,B_SR]=GetInvGammaParameters(0.5,1);
% S_pi: Inverse Gamma, domain: R+
[A_Spi,B_Spi]=GetInvGammaParameters(0.5,1);
% S_y: Inverse Gamma, domain: R+
[A_Sy,B_Sy]=GetInvGammaParameters(0.5,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Alpha: Beta, domain: [0,1)
mode_Alpha=0.588;
std_Alpha=0.02;
[A_Alpha,B_Alpha]=GetBetaParameters(mode_Alpha,std_Alpha);
% Theta-1: Gamma, domain: R+ [Theta must be greater than 1, so we specify the prior in terms of Theta-1]
[A_Theta_1,B_Theta_1]=GetGammaParameters(5,5);
% Epsi: Beta [0 1]
mode_Epsi=0.8;
std_Epsi=0.1;
[A_Epsi,B_Epsi]=GetBetaParameters(mode_Epsi,std_Epsi);
% Sigma: Gamma, domain: R+
mode_Sigma=2;
std_Sigma=1;
[A_Sigma,B_Sigma]=GetGammaParameters(mode_Sigma,std_Sigma);
% Gamma: Beta [0 1]
mode_Gamma=0.8;
std_Gamma=0.1;
[A_Gamma,B_Gamma]=GetBetaParameters(mode_Gamma,std_Gamma);
% Rho: Beta, domain: [0,1)
mode_Rho=0.8;
std_Rho=0.1;
[A_Rho,B_Rho]=GetBetaParameters(mode_Rho,std_Rho);
% Phi_pi: Gamma, domain: R+
mode_Phi_pi=1;
std_Phi_pi=0.5;
[A_Phi_pi,B_Phi_pi]=GetGammaParameters(mode_Phi_pi,std_Phi_pi);
% Phi_y: Gamma, domain: R+
mode_Phi_y=0.1;
std_Phi_y=0.25;
[A_Phi_y,B_Phi_y]=GetGammaParameters(mode_Phi_y,std_Phi_y);
% Rho_R: Beta, domain: [0,1)
% Rho_y: Beta, domain: [0,1)
mode_Rhos=0.25;
std_Rhos=0.1;
[A_Rhos,B_Rhos]=GetBetaParameters(mode_Rhos,std_Rhos);
%
A=[A_SR A_Spi A_Sy A_Alpha A_Theta_1 A_Sigma A_Rho A_Phi_pi A_Phi_y A_Rhos A_Epsi A_Gamma]';
B=[B_SR B_Spi B_Sy B_Alpha B_Theta_1 B_Sigma B_Rho B_Phi_pi B_Phi_y B_Rhos B_Epsi B_Gamma]';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % mode_Phi_y=0.1;
% % std_Phi_y=0.25;
% % [A_Phi_y,B_Phi_y]=GetGammaParameters(mode_Phi_y,std_Phi_y);
% % Domain=linspace(0,10,1000)';
% % PDF=zeros(size(Domain));
% % for jj=1:1000
% %     PDF(jj)=gampdf(Domain(jj),A_Phi_y,B_Phi_y);
% % end
% % plot(Domain,PDF)
% % %
% % mode_Rhos=0.25;
% % std_Rhos=0.1;
% % [A_Rhos,B_Rhos]=GetBetaParameters(mode_Rhos,std_Rhos);
% % Domain=linspace(0,1,1000)';
% % PDF=zeros(size(Domain));
% % for jj=1:1000
% %     PDF(jj)=betapdf(Domain(jj),A_Rhos,B_Rhos);
% % end
% % plot(Domain,PDF)
% % % 
% % % [A_SR,B_SR]=GetInvGammaParameters(0.5,5);
% % % Domain=linspace(0,10,1000)';
% % % PDF=zeros(size(Domain));
% % % for jj=1:1000
% % %     PDF(jj)=InvGammaPDF(Domain(jj),A_SR,B_SR);
% % % end
% % % plot(Domain,PDF)
% % % 
% % 
% % 
% % % 
% % 
% % 
% % 
% % 
% % 
% % 
