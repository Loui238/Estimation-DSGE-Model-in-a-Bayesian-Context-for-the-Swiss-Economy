function [BLower,BUpper]=GetLimitsAscariRopele(Y)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Lower bounds for the parameters:
VarsLower=eps;
ThetaMinus1Lower=eps;
AlphaLower=0.52;
EpsiLower=eps;
SigmaLower=eps;
DeltaLower=0;
Phi_piLower=0.1;
Phi_yLower=eps;
RhoLower=0.4;
RhosLower=0.01;
% Upper bounds for the parameters:
VarsUpper=8;
ThetaMinus1Upper=25;
AlphaUpper=0.66;
EpsiUpper=1-eps;
SigmaUpper=7;
DeltaUpper=1;
Phi_piUpper=3.5;
Phi_yUpper=1.6;
RhoUpper=1-eps;
RhosUpper=0.65;
%
BLower=[ones(1,3)*eps ThetaMinus1Lower AlphaLower EpsiLower SigmaLower DeltaLower RhoLower Phi_piLower Phi_yLower ones(1,2)*RhosLower]';
BUpper=[ones(1,3)*VarsUpper ThetaMinus1Upper AlphaUpper EpsiUpper SigmaUpper DeltaUpper RhoUpper Phi_piUpper Phi_yUpper ones(1,2)*RhosUpper]';







