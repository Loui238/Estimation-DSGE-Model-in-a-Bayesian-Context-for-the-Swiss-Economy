%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
path(path,'U:\LouisRonchi\SeminarPaper')
options = optimset;
options = optimset(options,'Display','off');
warning('off','all')

Period='One';
NumberOfDraws=2000;
Intercept='Y';
Horizon = 4*10;
Stationary='N';

NN = NumberOfDraws;

X=xlsread('U:\LouisRonchi\SeminarPaper\CanadaData_paper.xlsx','Canada','A35:I218');
%X=xlsread('/Users/louis/Desktop/ALL/programming/matlab/Seminarpaper/CanadaData_paper.xlsx','Canada','A35:I218');
[T,N]=size(X);

Time = X(2:T,1);
GDP = X(2:T,2);
unemployment_rate = X(2:T,3);
cpi = X(2:T,4);
gross_consumption_expenditure = X(:,5);
gross_capital_formation = X(:,6);
short_rate = X(2:T,7)/100;
Rate = short_rate;
long_rate = X(2:T,8)/100;
gdp_implicit_deflator = X(:,9);

OutputGap=MyHPFilter(log(GDP),1600);
LogGDPDeflator = log(gdp_implicit_deflator);
Inflation=((diff(LogGDPDeflator)+1).^4-1);
%  
Y =[Rate Inflation OutputGap]*100; 
[T,N]=size(Y);

if Period=='One'
    Start=1;
    End=minindc(abs(Time-1993));
    DFILE=['U:\LouisRonchi\SeminarPaper\MaxLogPosteriorCanadaPeriodOneAscariRopele'];
else
    Start=minindc(abs(Time-1993))+1;
    End=T;
    DFILE=['U:\LouisRonchi\SeminarPaper\MaxLogPosteriorCanadaPeriodTwoAscariRopele'];
end
Y=Y(Start:End,:);
Time=Time(Start:End);
Rate=Y(:,1);
Inflation=Y(:,2);
OutputGap=Y(:,3);

T=size(Y,1);
Trend='Y';
InflationT=mean(Inflation);
InfT=(InflationT/100+1)^0.25;
%
[BLower,BUpper]=GetLimitsAscariRopele(Y); 
[A,B]=GetPriorsAscariRopele(Trend);
%

T0=100000;
rT=0.8;
Nt=5;
Ns=20;
MaxNEval=10000;



% Variables to be saved:
varname(1,:) = ['BHAT'];
varname(2,:) = ['FFFF'];
varname(3,:) = ['NNNN'];



 [Bhat,Fopt,Nevals]=SimulAnnAscariRopele(Y,BLower,BUpper,A,B,T0,rT,Nt,Ns,MaxNEval,InfT,T);
 save(DFILE,varname(1,:),varname(2,:),varname(3,:))
 format long
 Bhat=Bhat(:)
 format short


if Period=='One'
    Bhat=[1.538852752648230
   6.641105635491424
   0.168304963996222
   8.474983405524558
   0.641437987277397
   0.437430077230245
   8.226336617726306
   0.861216563277140
   0.834047186165430
   1.977390793406553
   1.315206802099157
   0.297305011528879
   0.712849269194807];
else
    Bhat=[0.910923367562179
   3.747362691737664
   0.445206152599725
  19.388226415466246
   0.637451377360298
   0.407781085407581
   5.694920209855213
   0.952626697105784
   0.796497482259239
   1.546721079865036
   0.090194359583733
   0.306870609380049
   0.616444600175464];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[YHAT,INST]=YhatAscariRopele(Bhat,Y,InfT,T);
RateHat=YHAT(:,1)+InflationT+mean(Rate-InflationT);
if Trend=='N'
    InflationHat=YHAT(:,2)+mean(Inflation-InflationT);
else
    InflationHat=YHAT(:,2)+InflationT;
end
OutputGapHat=YHAT(:,3);
T=length(Time);
%
figure(1)
subplot(2,2,1)
plot(Time,Rate,'k',Time,RateHat,'r')
axis([Time(1) Time(T) min(Rate) 1.1*max(Rate)])
subplot(2,2,2)
plot(Time,Inflation,'k',Time,InflationHat,'r')
axis([Time(1) Time(T) min(Inflation) 1.1*max(Inflation)])
subplot(2,2,3)
plot(Time,OutputGap,'k',Time,OutputGapHat,'r')
axis([Time(1) Time(T) 1.1*min(OutputGap) 1.1*max(OutputGap)])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Here we get the Hessian of the log-likelihood function at the modal
% estimate, based on the Berndt-Hall-Hall-Hausman 'outer product' formula
% as found in Hamilton's books.
P=GetPAscariRopele(Bhat,Y,InfT,T);
[Bhat sqrt(diag(P))]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                    Here we do Random Walk Metropolis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                           I: The burn-in period
%
Desired=0.23; % Desired acceptance rate of the draws
BurnInNN=100000; % Number of burn-in iterations
SamplingInterval=100;
ErgodicNN=1000*SamplingInterval; % Number of iterations of the ergodic distribution
IntervalForResettingOfc=10000;
%
% The 'scale parameter' c, to be adjusted so that the acceptance
% rate of the draws is close to the desired acceptance rate, 0.23:
c=0.25;
% The scaling matrix to be used when drawing in the Markov chain:
RR=c*chol(P)';
%
KK=size(Bhat,1);
BHAT=zeros(size(Bhat,1),BurnInNN);
%
% We will draw from a multivariate N(0,1) distribution.
% Then we will multiply it by RR (the Cholesky factor of the rescaled
% Hessian), and we will sum it to BB. In this way, we end up drawing from
% multivariate normal with mean BB and covariance matrix (c^2 * P), which
% is what we want ...
%
% Therefore, these are the mean and covariance matrix we will use to draw
% from a multivariate N(0,1) distribution. The mean is a vectror of zeros,
% the covariance matrix the identity matrix:
DrawMean=zeros(size(Bhat,1),1);
DrawCovariance=eye(size(Bhat,1));
%
% Here we start the Markov chain, by setting the initial value of BB to the
% one corresponding to the mode of the log posterior, Bhat:
BB=Bhat;
%
% Log-likelihood conditional on the starting value:
LikeOld=-LogLikelihoodAscariRopele(BB,Y,InfT,T);
%
% The prior density conditional on the starting value. Notice that the function is
% LogPriorDensityAscariRopele, bit since we enter 'Y' as its fourth
% argument in the line below, it returns to us the prior densitiy,
% rather than the logarithm of the prior density: check the code
% LogPriorDensityAscariRopele at the very end to see this ...
BayesOld=LogPriorDensityAscariRopele(BB,A,B,'Y');
%
% The number of accepted draws:
Accepted=0;
%
% The first element of the Markov chain:
BHAT(:,1)=BB;
%
jj=1;
while jj<BurnInNN
    BurnInNN-jj
    % Here we draw until we get a proposal draw which is fine.
    % Specifically:
    % (i) all of the parameters must be positive (this is peculiar of this
    %     particular DSGE model, it's not a general requiremnt;
    % (ii) the new value of the log-likelihood must be different from the
    %      old one
    Index=-9999;
    while Index<0
        % Proposal draw:
        BBProposal=BB+RR*mvnrnd(DrawMean,DrawCovariance,1)';
        if sum(BBProposal>0)==KK
            LikeNew=-LogLikelihoodAscariRopele(BBProposal,Y,InfT,T);
            if LikeNew~=-1.0e+100 & LikeNew~=LikeOld
                Index=1;
            end
        end
    end
    % Here we get the prior density. Notice that the function is
    % LogPriorDensityAscariRopele, but since we enter 'Y' as its fourth
    % argument in the line below, it returns to us the prior densitiy,
    % rather than the logarithm of the prior density: check the code
    % LogPriorDensityAscariRopele at the very end to see this ...
    BayesNew=LogPriorDensityAscariRopele(BBProposal,A,B,'Y');
    if BayesNew==0
        % (1) If the proposal draw is completely implausible from the
        % perspective of the prior -- that is: its prior density is equal
        % to zero -- we reject it, and we stay where we are in the Markov
        % chain:
        BHAT(:,jj)=BB;
        jj=jj+1;
    else
        % (2) If the proposal draw is not completely implausible from the
        % perspective of the prior, we see whether we accept it or not:
        %
        % This is the product of two ratios:
        % (i) the ratio between the 2 likelihoods (new and old), and
        % (ii) the ratio between the 2 Bayes factors (new and old).
        R=exp(LikeNew-LikeOld)*(BayesNew/BayesOld);
        % If the ratio is above 1 we reset it to one:
        R=min([R 1]');
        % Evaluating the proposal draw: we draw a random number on the
        % uniform [0,1] distribution, and we accept the proposal draw
        % if R is greater than this random number:
        r=rand;
        if R>=r
            Accepted=Accepted+1;
            BB=BBProposal;
            LikeOld=LikeNew;
            BayesOld=BayesNew;
        end
        BHAT(:,jj)=BB;
        jj=jj+1;
    end
    if (jj/IntervalForResettingOfc)==fix(jj/IntervalForResettingOfc)
        BurnInNN-jj
        Fraction=Accepted/IntervalForResettingOfc
        if Fraction<0.21
            RR=RR*0.9;
        elseif Fraction>0.25
            RR=RR*1.1;
        else
        end
        Accepted=0;
    end
end
% plot(BHAT(:,1:jj-1)')
% plot(BHAT(:,1:SamplingInterval:jj-1)')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                           II: The ergodic distribution:
clear DFILE varname BHAT

if Period=='One'
    DFILE=['U:\LouisRonchi\SeminarPaper\ErgodicDistributionCanadaPeriodOneAscariRopele'];
else
    DFILE=['U:\LouisRonchi\SeminarPaper\ErgodicDistributionCanadaPeriodTwoAscariRopele'];
end

varname(1,:)=['FRAC'];
varname(2,:)=['BHAT'];
%


LikeOld=-LogLikelihoodAscariRopele(BB,Y,InfT,T);
BayesOld=LogPriorDensityAscariRopele(BB,A,B,'Y');
%
Accepted=0;
accepted=0;
Fraction=1;
%
jj=1;
while jj<ErgodicNN
    jj
    if (jj/10000)==fix(jj/10000)
        FRAC=Accepted/jj;
        ErgodicNN-jj
    end
    Index=-9999;
    while Index<0
        % Proposal draw:
        BBProposal=BB+RR*mvnrnd(DrawMean,DrawCovariance,1)';
        if sum(BBProposal>0)==KK
            LikeNew=-LogLikelihoodAscariRopele(BBProposal,Y,InfT,T);
            if LikeNew~=-1.0e+100 & LikeNew~=LikeOld
                Index=1;
            end
        end
    end
    BayesNew=LogPriorDensityAscariRopele(BBProposal,A,B,'Y');
    if BayesNew==0
        jj=jj+1;
    else
        R=exp(LikeNew-LikeOld)*(BayesNew/BayesOld);
        R=min([R 1]');
        r=rand;
        if R>=r
            accepted=accepted+1;
            Accepted=Accepted+1;
            BB=BBProposal;
            LikeOld=LikeNew;
            BayesOld=BayesNew;
        end
        jj=jj+1;
    end
    if (jj/SamplingInterval)==fix(jj/SamplingInterval)
        K=(jj/SamplingInterval)
        FRAC=Fraction;
        BHAT(:,K)=BB;
        save(DFILE,varname(1,:),varname(2,:));
    end
    if (jj/IntervalForResettingOfc)==fix(jj/IntervalForResettingOfc)
        Fraction=accepted/IntervalForResettingOfc
        if Fraction<0.21
            RR=RR*0.9;
        elseif Fraction>0.25
            RR=RR*1.1;
        else
        end
        accepted=0;
    end
end
%
FRAC=Accepted/ErgodicNN;
BHAT=BHAT';
save(DFILE,varname(1,:),varname(2,:));

%
[N,C]=size(BHAT);
SortedBHAT=sort(BHAT);
for jj=1:C
    Grid=linspace(min(SortedBHAT(:,jj)),max(SortedBHAT(:,jj)),100)';
    [PDF,Grid]=PDFContour(SortedBHAT(:,jj),Grid);
    [nn,Index]=max(PDF);
    Mode(jj,1)=Grid(Index);
end
[Mode SortedBHAT(fix(N*[0.05 0.95]'),:)']
MedianEstimate=SortedBHAT(fix(N*0.5),:)';
N=size(Y,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[YHAT,INST]=YhatAscariRopele(MedianEstimate,Y,InfT,T);
RateHat=YHAT(:,1)+InflationT+mean(Rate-InflationT);
if Trend=='N'
    InflationHat=YHAT(:,2)+mean(Inflation-InflationT);
else
    InflationHat=YHAT(:,2)+InflationT;
end
OutputGapHat=YHAT(:,3);
T=length(Time);
%
figure(2)
subplot(2,2,1)
plot(Time,Rate,'k',Time,RateHat,'r')
axis([Time(1) Time(T) min(Rate) 1.1*max(Rate)])
subplot(2,2,2)
plot(Time,Inflation,'k',Time,InflationHat,'r')
axis([Time(1) Time(T) min(Inflation) 1.1*max(Inflation)])
subplot(2,2,3)
plot(Time,OutputGap,'k',Time,OutputGapHat,'r')
axis([Time(1) Time(T) 1.1*min(OutputGap) 1.1*max(OutputGap)])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Let's check the fraction of accepted draws, to see whether we are
% reasonably close to the ideal one (in  high dimensions) of 0.23:
FRAC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%                       Here we get the IRFs and fractions of FEV:
NN=size(BHAT,1);
Horizon=10*4;
%
Draw=1;
while Draw<NN
    [F,A0,H]=GetStateSpaceAscariRopele(BHAT(Draw,:)',InfT);
    FractionsOfFEV(:,:,:,Draw)=GetFEVsDSGEModel(F,A0,H,Horizon);
    IRFs(:,:,:,Draw)=GetIRFsDSGEModel(F,A0,H,Horizon);
    Draw=Draw+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                       Here we plot the IRFs and fractions of FEV:
HOR=(0:1:Horizon)';
%
Variable=1;
while Variable<=N
    Shock=1;
    while Shock<=N
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Here we plot the IRFs:
        IRF=ExtractPercentiles(squeeze(IRFs(:,Variable,Shock,:))',[0.5 0.16 0.84 0.05 0.95]')';
        figure(2)
        subplot(N,N,(Shock-1)*N+Variable)
        plot(HOR,zeros(size(HOR)),'b:',HOR,IRF(:,1),'k',HOR,IRF(:,2:3),'r:',HOR,IRF(:,4:5),'r','LineWidth',2)
        xlim([0 Horizon])
        if Variable==1
            title('Rate')
        elseif Variable==2
            title('Inflation')
        elseif Variable==3
            title('OutputGap')
        else
        end
        if Shock==1
            xlabel('e_R(t)')
        elseif Shock==2
            xlabel('e_pi(t)')
        elseif Shock==3
            xlabel('e_y(t)')
        else
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Here we plot the fractions of FEV:
        FEV=ExtractPercentiles(squeeze(FractionsOfFEV(:,Variable,Shock,:))',[0.5 0.16 0.84 0.05 0.95]')';
        figure(3)
        subplot(N,N,(Shock-1)*N+Variable)
        plot(HOR,FEV(:,1),'k',HOR,FEV(:,2:3),'r:',HOR,FEV(:,4:5),'r','LineWidth',2)
        axis([0 Horizon 0 1])
        if Variable==1
            title('Rate')
        elseif Variable==2
            title('Inflation')
        elseif Variable==3
            title('OutputGap')
        else
        end
        if Shock==1
            xlabel('e_R(t)')
        elseif Shock==2
            xlabel('e_pi(t)')
        elseif Shock==3
            xlabel('e_y(t)')
        else
        end
        Shock=Shock+1;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    Variable=Variable+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



