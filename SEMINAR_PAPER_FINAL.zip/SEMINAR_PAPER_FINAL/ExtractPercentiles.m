function PercentilesY=ExtractPercentiles(Y,Percentiles)
[T,N]=size(Y);
if min(Percentiles)<=0 | max(Percentiles)>=1
    disp('Percentiles have been badly defined')
    return
end
Y=sort(Y);
Percentiles=fix(Percentiles*T);
for xx=1:N
    PercentilesY(:,xx)=Y(Percentiles,xx);
end
