function Index=minindc(X)
% Luca Benati
% European Central Bank
% Monetary Policy Strategy Division
% May 2009
%
% Index=minindc(X)
% This function is modelled on the Gauss function minindc.
X=-X;
[Y,Index]=max(X);


