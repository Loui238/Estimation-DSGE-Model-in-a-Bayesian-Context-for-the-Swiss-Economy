%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
path(path,'U:\SeminarEmpiricalMacro\AscariRopele\')
path(path,'U:\SeminarEmpiricalMacro\')
options = optimset;
options = optimset(options,'Display','off');
warning('off','all')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Country='US'; % 'UK' 'AU' 'US'
Period='One'; % 'Two' (recent, stable monetary regime) or 'One' (previous, less stable monetary regime)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Country=='UK'
    [Y,B]=xlsread('U:\SeminarEmpiricalMacro\AscariRopele\AscariRopeleData.xls','QuarterlyData','K79:L270');
    Time=Y(:,1);
    Y=Y(:,2);
    OutputGap=MyHPFilter(log(Y),1600)*100;
    if Period=='One'
        OutputGap=OutputGap(2:find(Time==1992.75));
        [X,B]=xlsread('U:\SeminarEmpiricalMacro\AscariRopele\AscariRopeleData.xls','QuarterlyData','K79:U161');
    else
        OutputGap=OutputGap(find(Time==1993):length(OutputGap));
        [X,B]=xlsread('U:\SeminarEmpiricalMacro\AscariRopele\AscariRopeleData.xls','QuarterlyData','K161:U270');
    end
    [T,N]=size(X);
    Time=X(2:T,1);
    Rate=X(2:T,6);
    LogGDPDeflator=log(X(:,11));
    Inflation=((diff(LogGDPDeflator)+1).^4-1)*100;
    Y=[Rate Inflation OutputGap];
elseif Country=='AU'
    [X,B]=xlsread('U:\SeminarEmpiricalMacro\AscariRopele\AscariRopeleData.xls','QuarterlyData','AO51:AR252');
    [T,N]=size(X);
    Time=X(2:T,1);
    Rate=X(2:T,3);
    LogGDPDeflator=log(X(:,4)./X(:,2));
    Inflation=((diff(LogGDPDeflator)+1).^4-1)*100;
    OutputGap=MyHPFilter(log(X(:,2)),1600)*100;
    Y=[Rate Inflation OutputGap(2:end)];
    [T,N]=size(Y);
    if Period=='One'
        Start=1;
        End=minindc(abs(Time-1990));
    else
        Start=minindc(abs(Time-1990))+1;
        End=T;
    end
    Y=Y(Start:End,:);
    Time=Time(Start:End);
    Rate=Y(:,1);
    Inflation=Y(:,2);
    OutputGap=Y(:,3);
elseif Country=='US'
    [X,B]=xlsread('U:\SeminarEmpiricalMacro\AscariRopele\AscariRopeleData.xls','QuarterlyData','AT41:AW302');
    [T,N]=size(X);
    Time=X(2:T,1);
    Rate=X(2:T,3);
    LogGDPDeflator=log(X(:,4));
    Inflation=((diff(LogGDPDeflator)+1).^4-1)*100;
    OutputGap=MyHPFilter(log(X(:,2)),1600)*100;
    Y=[Rate Inflation OutputGap(2:end)];
    [T,N]=size(Y);
    if Period=='One'
        Start=1;
        End=minindc(abs(Time-1983));
    else
        Start=minindc(abs(Time-1983))+1;
        End=T;
    end
    Y=Y(Start:End,:);
    Time=Time(Start:End);
    Rate=Y(:,1);
    Inflation=Y(:,2);
    OutputGap=Y(:,3);
else
end
T=size(Y,1);
Trend='Y';
InflationT=mean(Inflation);
InfT=(InflationT/100+1)^0.25;
%
[BLower,BUpper]=GetLimitsAscariRopele(Y);
[A,B]=GetPriorsAscariRopele(Trend);
%
T0=100000;
rT=0.8;
Nt=5;
Ns=20;
MaxNEval=10000;
%
if Country=='UK'
    if Period=='One'
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\MaxLogPosteriorUKPeriodOneAscariRopele'];
    else
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\MaxLogPosteriorUKPeriodTwoAscariRopele'];
    end
elseif Country=='AU'
    if Period=='One'
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\MaxLogPosteriorAUPeriodOneAscariRopele'];
    else
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\MaxLogPosteriorAUPeriodTwoAscariRopele'];
    end
elseif Country=='US'
    if Period=='One'
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\MaxLogPosteriorUSPeriodOneAscariRopele'];
    else
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\MaxLogPosteriorUSPeriodTwoAscariRopele'];
    end
else
end
% Variables to be saved:
varname(1,:) = ['BHAT'];
varname(2,:) = ['FFFF'];
varname(3,:) = ['NNNN'];
%
% [Bhat,Fopt,Nevals]=SimulAnnAscariRopele(Y,BLower,BUpper,A,B,T0,rT,Nt,Ns,MaxNEval,InfT,T);
% format long
% Bhat=Bhat(:)
% format short
%
if Country=='UK'
    if Period=='One'
        Bhat=[1.761608025548852
            40.223543433734022
            0.357195291932972
            11.835022036834790
            0.572134636006422
            0.431861588829926
            8.768451169757428
            0.737085550292918
            0.583913560050687
            0.270022551109144
            0.321597102155265
            0.285597337637933
            0.471884269682182];
    else
        Bhat=[0.167300434552076
            7.538347919687775
            0.100747870563238
            0.975337268551624
            0.599041147714594
            0.113621746640989
            8.972842952226561
            0.610688413233940
            0.787202668613180
            0.225824988002246
            1.507853921233408
            0.636646263903800
            0.590954677146024];
    end
elseif Country=='AU'
    if Period=='One'
        Bhat=[4.117123964631280
            28.747502040693849
            0.432549717791429
            11.014545455514959
            0.610053839434548
            0.436454764857239
            12.762006653731717
            0.878897475664236
            0.828246573659662
            1.789863781756338
            0.101494465127143
            0.170614241021972
            0.505048060978556];
    else
        Bhat=[0.214423994737142
            10.630586793982191
            0.107837811351366
            0.831571209082354
            0.577646552170086
            0.183993018408243
            14.731750135293396
            0.877960704869259
            0.733760119535179
            0.165498029119062
            1.064958048035829
            0.563868809913589
            0.497044286796343];
    end
elseif Country=='US'
    if Period=='One'
        Bhat=[2.656929741322329
            2.456350991404558
            1.755769155599234
            12.788227304985647
            0.606400301394078
            0.597392691079732
            2.301420408172495
            0.880845158654801
            0.459453405182599
            2.317620079127514
            0.429695981565766
            0.551686770256212
            0.507639064069133];
    else
        Bhat=[0.292416751466068
            0.818002436237480
            0.087303332773741
            27.075358599384209
            0.648787850218998
            0.425794976502013
            4.021241678910348
            0.424240281367003
            0.824684511398735
            3.128878664400097
            1.666488663247477
            0.423172832726335
            0.803454279105899];
    end
else
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[YHAT,INST]=YhatAscariRopele(Bhat,Y,InfT,T);
RateHat=YHAT(:,1)+InflationT+mean(Rate-InflationT);
if Trend=='N'
    InflationHat=YHAT(:,2)+mean(Inflation-InflationT);
else
    InflationHat=YHAT(:,2)+InflationT;
end
OutputGapHat=YHAT(:,3);
T=length(Time);
%
figure(1)
subplot(2,2,1)
plot(Time,Rate,'k',Time,RateHat,'r')
axis([Time(1) Time(T) min(Rate) 1.1*max(Rate)])
subplot(2,2,2)
plot(Time,Inflation,'k',Time,InflationHat,'r')
axis([Time(1) Time(T) min(Inflation) 1.1*max(Inflation)])
subplot(2,2,3)
plot(Time,OutputGap,'k',Time,OutputGapHat,'r')
axis([Time(1) Time(T) 1.1*min(OutputGap) 1.1*max(OutputGap)])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Here we get the Hessian of the log-likelihood function at the modal
% estimate, based on the Berndt-Hall-Hall-Hausman 'outer product' formula
% as found in Hamilton's books.
P=GetPAscariRopele(Bhat,Y,InfT,T);
[Bhat sqrt(diag(P))]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                    Here we do Random Walk Metropolis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                           I: The burn-in period
%
Desired=0.23; % Desired acceptance rate of the draws
BurnInNN=100000; % Number of burn-in iterations
SamplingInterval=100;
ErgodicNN=1000*SamplingInterval; % Number of iterations of the ergodic distribution
IntervalForResettingOfc=10000;
%
% The 'scale parameter' c, to be adjusted so that the acceptance
% rate of the draws is close to the desired acceptance rate, 0.23:
c=0.25;
% The scaling matrix to be used when drawing in the Markov chain:
RR=c*chol(P)';
%
KK=size(Bhat,1);
BHAT=zeros(size(Bhat,1),BurnInNN);
%
% We will draw from a multivariate N(0,1) distribution.
% Then we will multiply it by RR (the Cholesky factor of the rescaled
% Hessian), and we will sum it to BB. In this way, we end up drawing from
% multivariate normal with mean BB and covariance matrix (c^2 * P), which
% is what we want ...
%
% Therefore, these are the mean and covariance matrix we will use to draw
% from a multivariate N(0,1) distribution. The mean is a vectror of zeros,
% the covariance matrix the identity matrix:
DrawMean=zeros(size(Bhat,1),1);
DrawCovariance=eye(size(Bhat,1));
%
% Here we start the Markov chain, by setting the initial value of BB to the
% one corresponding to the mode of the log posterior, Bhat:
BB=Bhat;
%
% Log-likelihood conditional on the starting value:
LikeOld=-LogLikelihoodAscariRopele(BB,Y,InfT,T);
%
% The prior density conditional on the starting value. Notice that the function is
% LogPriorDensityAscariRopele, bit since we enter 'Y' as its fourth
% argument in the line below, it returns to us the prior densitiy,
% rather than the logarithm of the prior density: check the code
% LogPriorDensityAscariRopele at the very end to see this ...
BayesOld=LogPriorDensityAscariRopele(BB,A,B,'Y');
%
% The number of accepted draws:
Accepted=0;
%
% The first element of the Markov chain:
BHAT(:,1)=BB;
%
jj=1;
while jj<BurnInNN
    % jj
    % Here we draw until we get a proposal draw which is fine.
    % Specifically:
    % (i) all of the parameters must be positive (this is peculiar of this
    %     particular DSGE model, it's not a general requiremnt;
    % (ii) the new value of the log-likelihood must be different from the
    %      old one
    Index=-9999;
    while Index<0
        % Proposal draw:
        BBProposal=BB+RR*mvnrnd(DrawMean,DrawCovariance,1)';
        if sum(BBProposal>0)==KK
            LikeNew=-LogLikelihoodAscariRopele(BBProposal,Y,InfT,T);
            if LikeNew~=-1.0e+100 & LikeNew~=LikeOld
                Index=1;
            end
        end
    end
    % Here we get the prior density. Notice that the function is
    % LogPriorDensityAscariRopele, but since we enter 'Y' as its fourth
    % argument in the line below, it returns to us the prior densitiy,
    % rather than the logarithm of the prior density: check the code
    % LogPriorDensityAscariRopele at the very end to see this ...
    BayesNew=LogPriorDensityAscariRopele(BBProposal,A,B,'Y');
    if BayesNew==0
        % (1) If the proposal draw is completely implausible from the
        % perspective of the prior -- that is: its prior density is equal
        % to zero -- we reject it, and we stay where we are in the Markov
        % chain:
        BHAT(:,jj)=BB;
        jj=jj+1;
    else
        % (2) If the proposal draw is not completely implausible from the
        % perspective of the prior, we see whether we accept it or not:
        %
        % This is the product of two ratios:
        % (i) the ratio between the 2 likelihoods (new and old), and
        % (ii) the ratio between the 2 Bayes factors (new and old).
        R=exp(LikeNew-LikeOld)*(BayesNew/BayesOld);
        % If the ratio is above 1 we reset it to one:
        R=min([R 1]');
        % Evaluating the proposal draw: we draw a random number on the
        % uniform [0,1] distribution, and we accept the proposal draw
        % if R is greater than this random number:
        r=rand;
        if R>=r
            Accepted=Accepted+1;
            BB=BBProposal;
            LikeOld=LikeNew;
            BayesOld=BayesNew;
        end
        BHAT(:,jj)=BB;
        jj=jj+1;
    end
    if (jj/IntervalForResettingOfc)==fix(jj/IntervalForResettingOfc)
        BurnInNN-jj
        Fraction=Accepted/IntervalForResettingOfc
        if Fraction<0.21
            RR=RR*0.9;
        elseif Fraction>0.25
            RR=RR*1.1;
        else
        end
        Accepted=0;
    end
end
% plot(BHAT(:,1:SamplingInterval:jj-1)')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                           II: The ergodic distribution:
clear DFILE varname BHAT
if Country=='UK'
    if Period=='One'
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\ErgodicDistributionUKPeriodOneAscariRopele'];
    else
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\ErgodicDistributionUKPeriodTwoAscariRopele'];
    end
elseif Country=='AU'
    if Period=='One'
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\ErgodicDistributionAUPeriodOneAscariRopele'];
    else
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\ErgodicDistributionAUPeriodTwoAscariRopele'];
    end
elseif Country=='US'
    if Period=='One'
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\ErgodicDistributionUSPeriodOneAscariRopele'];
    else
        DFILE=['U:\SeminarEmpiricalMacro\AscariRopele\ErgodicDistributionUSPeriodTwoAscariRopele'];
    end
else
end
varname(1,:)=['FRAC'];
varname(2,:)=['BHAT'];
%
LikeOld=-LogLikelihoodAscariRopele(BB,Y,InfT,T);
BayesOld=LogPriorDensityAscariRopele(BB,A,B,'Y');
%
Accepted=0;
accepted=0;
Fraction=1;
%
jj=1;
while jj<ErgodicNN
    if (jj/10000)==fix(jj/10000)
        FRAC=Accepted/jj;
        ErgodicNN-jj
    end
    Index=-9999;
    while Index<0
        % Proposal draw:
        BBProposal=BB+RR*mvnrnd(DrawMean,DrawCovariance,1)';
        if sum(BBProposal>0)==KK
            LikeNew=-LogLikelihoodAscariRopele(BBProposal,Y,InfT,T);
            if LikeNew~=-1.0e+100 & LikeNew~=LikeOld
                Index=1;
            end
        end
    end
    BayesNew=LogPriorDensityAscariRopele(BBProposal,A,B,'Y');
    if BayesNew==0
        jj=jj+1;
    else
        R=exp(LikeNew-LikeOld)*(BayesNew/BayesOld);
        R=min([R 1]');
        r=rand;
        if R>=r
            accepted=accepted+1;
            Accepted=Accepted+1;
            BB=BBProposal;
            LikeOld=LikeNew;
            BayesOld=BayesNew;
        end
        jj=jj+1;
    end
    if (jj/SamplingInterval)==fix(jj/SamplingInterval)
        K=(jj/SamplingInterval)
        FRAC=Fraction;
        BHAT(:,K)=BB;
        save(DFILE,varname(1,:),varname(2,:));
    end
    if (jj/IntervalForResettingOfc)==fix(jj/IntervalForResettingOfc)
        Fraction=accepted/IntervalForResettingOfc
        if Fraction<0.21
            RR=RR*0.9;
        elseif Fraction>0.25
            RR=RR*1.1;
        else
        end
        accepted=0;
    end
end
%
FRAC=Accepted/ErgodicNN;
BHAT=BHAT';
save(DFILE,varname(1,:),varname(2,:));
%
[N,C]=size(BHAT);
SortedBHAT=sort(BHAT);
for jj=1:C
    Grid=linspace(min(SortedBHAT(:,jj)),max(SortedBHAT(:,jj)),100)';
    [PDF,Grid]=PDFContour(SortedBHAT(:,jj),Grid);
    [nn,Index]=max(PDF);
    Mode(jj,1)=Grid(Index);
end
[Mode SortedBHAT(fix(N*[0.05 0.95]'),:)']
MedianEstimate=SortedBHAT(fix(N*0.5),:)';
N=size(Y,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[YHAT,INST]=YhatAscariRopele(MedianEstimate,Y,InfT,T);
RateHat=YHAT(:,1)+InflationT+mean(Rate-InflationT);
if Trend=='N'
    InflationHat=YHAT(:,2)+mean(Inflation-InflationT);
else
    InflationHat=YHAT(:,2)+InflationT;
end
OutputGapHat=YHAT(:,3);
T=length(Time);
%
figure(2)
subplot(2,2,1)
plot(Time,Rate,'k',Time,RateHat,'r')
axis([Time(1) Time(T) min(Rate) 1.1*max(Rate)])
subplot(2,2,2)
plot(Time,Inflation,'k',Time,InflationHat,'r')
axis([Time(1) Time(T) min(Inflation) 1.1*max(Inflation)])
subplot(2,2,3)
plot(Time,OutputGap,'k',Time,OutputGapHat,'r')
axis([Time(1) Time(T) 1.1*min(OutputGap) 1.1*max(OutputGap)])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Let's check the fraction of accepted draws, to see whether we are
% reasonably close to the ideal one (in  high dimensions) of 0.23:
disp('-------------------------------------------------------')
disp('This is the fraction of accepted draws:')
FRAC
disp('and it is reasonably close to the ideal one of 0.23 ...')
disp('-------------------------------------------------------')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                       Here we get the IRFs and fractions of FEV:
NN=size(BHAT,1);
Horizon=10*4;
%
Draw=1;
while Draw<NN
    [F,A0,H]=GetStateSpaceAscariRopele(BHAT(Draw,:)',InfT);
    FractionsOfFEV(:,:,:,Draw)=GetFEVsDSGEModel(F,A0,H,Horizon);
    IRFs(:,:,:,Draw)=GetIRFsDSGEModel(F,A0,H,Horizon);
    Draw=Draw+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                       Here we plot the IRFs and fractions of FEV:
HOR=(0:1:Horizon)';
%
Variable=1;
while Variable<=N
    Shock=1;
    while Shock<=N
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Here we plot the IRFs:
        IRF=ExtractPercentiles(squeeze(IRFs(:,Variable,Shock,:))',[0.5 0.16 0.84 0.05 0.95]')';
        figure(2)
        subplot(N,N,(Shock-1)*N+Variable)
        plot(HOR,zeros(size(HOR)),'b:',HOR,IRF(:,1),'k',HOR,IRF(:,2:3),'r:',HOR,IRF(:,4:5),'r','LineWidth',2)
        xlim([0 Horizon])
        if Variable==1
            title('Rate')
        elseif Variable==2
            title('Inflation')
        elseif Variable==3
            title('OutputGap')
        else
        end
        if Shock==1
            xlabel('e_R(t)')
        elseif Shock==2
            xlabel('e_pi(t)')
        elseif Shock==3
            xlabel('e_y(t)')
        else
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Here we plot the fractions of FEV:
        FEV=ExtractPercentiles(squeeze(FractionsOfFEV(:,Variable,Shock,:))',[0.5 0.16 0.84 0.05 0.95]')';
        figure(3)
        subplot(N,N,(Shock-1)*N+Variable)
        plot(HOR,FEV(:,1),'k',HOR,FEV(:,2:3),'r:',HOR,FEV(:,4:5),'r','LineWidth',2)
        axis([0 Horizon 0 1])
        if Variable==1
            title('Rate')
        elseif Variable==2
            title('Inflation')
        elseif Variable==3
            title('OutputGap')
        else
        end
        if Shock==1
            xlabel('e_R(t)')
        elseif Shock==2
            xlabel('e_pi(t)')
        elseif Shock==3
            xlabel('e_y(t)')
        else
        end
        Shock=Shock+1;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    Variable=Variable+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


