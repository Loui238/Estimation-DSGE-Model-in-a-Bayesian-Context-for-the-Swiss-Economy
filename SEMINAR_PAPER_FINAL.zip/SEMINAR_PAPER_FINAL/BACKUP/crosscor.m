function RHO=crosscor(y,x,k)
%		Luca Benati
%		Bank of England
%		Monetary Assessment and Strategy Division
%		December 2002
% function RHO=crosscor(y,x,k)
% This program computes the cross-correlations between 2 series of interest, y and x. In particular, x is the
% 'series of reference' (usually the series for GDP, or its cyclical component), while y is the series for
% which we want to compute the cross-correlation with respect to x (for example, unemployment). The output of
% the program is represented by a vector, RHO, containing the cross-correlations between y and x. Large and
% positive values of the first k entries of RHO, together with large and negative values of the last k entries
% of RHO, indicate that x leads y.
N=length(y);
ydem=y-mean(y);
xdem=x-mean(x);
g0yhat=(ydem'*ydem)/N;
g0xhat=(xdem'*xdem)/N;
%
for n=1:k
	Y=ydem(n+1:N);
	X=xdem(1:(N-n));
	RHO(k+1-n,1)=((Y'*X)/N)/((g0yhat*g0xhat)^0.5);
end
%
RHO(k+1,1)=((ydem'*xdem)/N)/((g0yhat*g0xhat)^0.5);
%
for n=1:k
	Y=ydem(1:(N-n));
	X=xdem(n+1:N);
	RHO(k+1+n,1)=((Y'*X)/N)/((g0yhat*g0xhat)^0.5);
end