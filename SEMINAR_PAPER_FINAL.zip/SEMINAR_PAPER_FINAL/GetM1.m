function M1=GetM1(G0,G1,CSI,PI,G0s,G1s,CSIs,PIs)
% Here the original matrices (for the indeterminacy solution):
[L,O,Q,Z]=qz(G0,G1);
[L,O,Q,Z]=qzdiv(1.0001,L,O,Q,Z); % Here we reorder the decomposition so that all the explosive eigenvalues are in the lower
lambda=diag(O)./diag(L); % The eigenvalues
INST=sum(abs(lambda)>=1); % The number of unstable eigenvalues
CSIstar=Q*CSI;
PIstar=Q*PI;
N=size(L,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PIJc=PIstar(1:N-INST,:);
CSIJc=CSIstar(1:N-INST,:);
PIJx=PIstar(N+1-INST:N,:);
CSIJx=CSIstar(N+1-INST:N,:);
L11=L(1:N-INST,1:N-INST);
O11=O(1:N-INST,1:N-INST);
Z1=Z(:,1:N-INST);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now the singular value decomposition of PIJx
[U,DD,V]=svd(PIJx);
[rDD,cDD]=size(DD);
sDD=min([rDD cDD]');
sDD=sDD-sum(diag(DD(1:sDD,1:sDD))==0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
GI0=Z1*(L11\(CSIJc+PIJc*(-V(:,1:sDD)*inv(DD(1:sDD,1:sDD))*U(:,1:sDD)'*CSIJx)));
GI1=Z1*(L11\(PIJc*(V(:,sDD+1:size(V,2)))));
% Here the matrices on the boundary (for the determinacy solution):
[L,O,Q,Z]=qz(G0s,G1s);
[L,O,Q,Z]=qzdiv(1.0001,L,O,Q,Z); % Here we reorder the decomposition so that all the explosive eigenvalues are in the lower
lambda=diag(O)./diag(L); % The eigenvalues
INST=sum(abs(lambda)>=1); % The number of unstable eigenvalues
CSIstars=Q*CSIs;
PIstars=Q*PIs;
N=size(L,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PIJcs=PIstars(1:N-INST,:);
CSIJcs=CSIstars(1:N-INST,:);
PIJxs=PIstars(N+1-INST:N,:);
CSIJxs=CSIstars(N+1-INST:N,:);
L11s=L(1:N-INST,1:N-INST);
O11s=O(1:N-INST,1:N-INST);
Z1s=Z(:,1:N-INST);
if size(PIJxs,1)~=size(PIJxs,2)
    M1=-9999;
    return
end
if abs(det(PIJxs))<1.0e-010
    M1=-9999;
    return
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
GD=Z1s*(L11s\(CSIJcs-PIJcs*inv(PIJxs)*CSIJxs));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M1=inv(GI1'*GI1)*GI1'*(GD-GI0);
