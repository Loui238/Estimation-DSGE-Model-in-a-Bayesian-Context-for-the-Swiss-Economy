function P=GetPAscariRopele(Bhat,Y,InfT,T);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% P       = the variance-covariance matrix of the MLE estimates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=size(Bhat,1);
BhatMaxLogPosterior=Bhat;
%
Delta=1.0e-14;
DeltaSaved=Delta;
BhatSaved=Bhat;
Delta=abs(Bhat*Delta);
Index=find((Delta)<eps);
Delta(Index)=ones(size(Index))*eps;
%
ii=1;
CheckTHETA=0;
while ii<=N
    % N-ii
    bhatL=Bhat;
    bhatL(ii)=bhatL(ii)-Delta(ii)/2;
    [~,TrendLLower]=LogLikelihoodAscariRopele(bhatL,Y,InfT,T);
    if TrendLLower==-9999
        CheckTHETA=-9999;
        break
    end
    bhatU=Bhat;
    bhatU(ii)=bhatU(ii)+Delta(ii)/2;
    [~,TrendLLUpper]=LogLikelihoodAscariRopele(bhatU,Y,InfT,T);
    if TrendLLUpper==-9999
        CheckTHETA=-9999;
        break
    end
    THETA(:,ii)=(TrendLLUpper-TrendLLower)/Delta(ii);
    ii=ii+1;
end
%
MeansDraws=zeros(size(BhatMaxLogPosterior,1),1);
CovarianceMatrixDraws=0.001*diag(abs(BhatMaxLogPosterior));
%
while CheckTHETA==-9999
    Bhat=BhatMaxLogPosterior+mvnrnd(MeansDraws,CovarianceMatrixDraws,1)';
    Delta=1.0e-002;
    Delta=abs(Bhat*Delta);
    ii=1;
    CheckTheta=0;
    while ii<=N
        bhatL=Bhat;
        bhatL(ii)=bhatL(ii)-Delta(ii)/2;
        TrendLLower=LLAscariRopele(bhatL,Rate,Inflation,OutputGap,InfT);
        if TrendLLower==-9999
            CheckTheta=-9999;
            break
        end
        bhatU=Bhat;
        bhatU(ii)=bhatU(ii)+Delta(ii)/2;
        TrendLLUpper=LLAscariRopele(bhatU,Rate,Inflation,OutputGap,InfT);
        if TrendLLUpper==-9999
            CheckTheta=-9999;
            break
        end
        THETA(:,ii)=(TrendLLUpper-TrendLLower)/Delta(ii);
        ii=ii+1;
    end
    if CheckTheta==0
        CheckTHETA=0;
    end
end
POP=zeros(size(Bhat,1));
for tt=1:size(THETA,1)
    theta=THETA(tt,:)';
    POP=POP+theta*theta';
end
P=inv(POP);



