function [MinusLogLikelihood,L]=LogLikelihoodAscariRopele(x,Y,InfT,T);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Beta=0.99;
SigmaN=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_R=x(1);
S_pi=x(2);
S_y=x(3);
Theta=1+x(4);
Alpha=x(5);
Epsi=x(6);
Sigma=x(7);
Gamma=x(8);
Rho=x(9);
Phi_pi=x(10);
Phi_y=x(11);
Rho_R=x(12);
Rho_y=x(13);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Position of the forecast errors in the vector eta:
% eta=[eta_inf(t) eta_y(t) eta_phi(t)]'
%          1         2         3
% Position of the shocks in the vector epsilon:
% epsilon=[e_R(t) e_pi(t) e_y(t)]'
%            1      2       3
% Position of the variables in the vector s(t):
% s(t)=[R(t) inf(t) y(t) phi(t) s(t) inf(t+1|t) y(t+1|t) phi(t+1|t) E_R(t) E_y(t)]'
%        1      2    3     4     5       6         7        8         9     10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PI=[zeros(5,3); eye(3); zeros(2,3)];
CSI=[diag([0 1 0]' ); zeros(5,3); 1 zeros(1,2); zeros(1,2) 1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Eta=Beta*(1-Alpha*InfT^((Theta-1)*(1-Epsi)))*(InfT^(1-Epsi)-1);
Csi=Eta*(Theta-1)+Beta*InfT^(1-Epsi);
Chi=Alpha*Beta*InfT^((Theta-1)*(1-Epsi));
Ecs=((InfT^(1-Epsi)-1)*(Theta*Alpha*InfT^((Theta-1)*(1-Epsi))))/...
    (1-Alpha*InfT^((Theta-1)*(1-Epsi)));
Kappa=(((1-Alpha*InfT^((Theta-1)*(1-Epsi)))*(1-Alpha*Beta*InfT^(Theta*(1-Epsi))))/...
    (Alpha*InfT^((Theta-1)*(1-Epsi))))*(1+SigmaN);
G0=[1 (Rho-1)*Phi_pi (Rho-1)*Phi_y zeros(1,5) -1 0; ...
    0 1+Csi*Epsi -Kappa 0 -Kappa*SigmaN/(1+SigmaN) -Csi 0 -Eta zeros(1,2); ...
    0 Chi*(Theta-1)*Epsi 0 1 0 -Chi*(Theta-1) 0 -Chi zeros(1,2); ...
    0 -Epsi zeros(1,2) 1 zeros(1,5); 1/Sigma 0 1 zeros(1,2) -1/Sigma -Gamma zeros(1,2) -1; ...
    zeros(3,1) eye(3) zeros(3,6); zeros(2,8) eye(2)];
G1=[diag([Rho Epsi]') zeros(2,8); zeros(1,10); 0 -Epsi*Ecs zeros(1,2) Alpha*InfT^(Theta*(1-Epsi)) zeros(1,5); ...
    zeros(1,2) (1-Gamma) zeros(1,7); zeros(3,5) eye(3) zeros(3,2); zeros(2,8) diag([Rho_R Rho_y]')];
% The matrices in the Sims canonical form:
[L,O,Q,Z]=qz(G0,G1);
[L,O,Q,Z]=qzdiv(1.0001,L,O,Q,Z); % Here we reorder the decomposition so that all the explosive eigenvalues are in the lower
Lambda=diag(O)./diag(L);  % The eigenvalues
INST=sum(abs(Lambda)>=1); % The number of unstable eigenvalues
N=size(G0,1);
%
if INST==2
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % This is the solution for the case of indeterminacy, that is: multiplicity of equilibria.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    PIstar=Q*PI;
    L22=L(N-INST+1:N,N-INST+1:N);
    PIstarx=L22\PIstar(N-INST+1:N,:);
    CSIstar=Q*CSI;
    L11=L(1:N-INST,1:N-INST);
    O11=O(1:N-INST,1:N-INST);
    % O22=O(N-INST+1:N,N-INST+1:N);
    Z1=Z(:,1:N-INST);
    %
    PIstarc=L11\PIstar(1:N-INST,:);
    CSIstarc=L11\CSIstar(1:N-INST,:);
    %
    CSIstarx=L22\CSIstar(N-INST+1:N,:);
    %
    % Getting phi_pis:
    PHI_PIS=linspace(0.25,1.25,1000)';
    Inst=zeros(size(PHI_PIS));
    Phi_pis=-9999;
    for jj=2:length(PHI_PIS)
        phi_pis=PHI_PIS(jj);
        g0=[1 (Rho-1)*phi_pis (Rho-1)*Phi_y zeros(1,5) -1 0; 0 1+Csi*Epsi -Kappa 0 -Kappa*SigmaN/(1+SigmaN) -Csi 0 -Eta zeros(1,2); ...
            0 Chi*(Theta-1)*Epsi 0 1 0 -Chi*(Theta-1) 0 -Chi zeros(1,2); 0 -Epsi zeros(1,2) 1 zeros(1,5); 1/Sigma 0 1 zeros(1,2) -1/Sigma -Gamma zeros(1,2) -1; ...
            zeros(3,1) eye(3) zeros(3,6); zeros(2,8) eye(2)];
        [L,O,qq,zz]=qz(g0,G1);
        Inst(jj)=sum(abs(diag(O)./diag(L))>=1); % The number of unstable eigenvalues
        if Inst(jj)==3 & Inst(jj-1)==2
            Phi_pis=phi_pis;
        end
    end
    if Phi_pis==-9999
        MinusLogLikelihood=1.0e+100;
        return
    end
    phi_pis=Phi_pis;
    % The matrices corresponding to the boundary solution:
    G0s=[1 (Rho-1)*phi_pis (Rho-1)*Phi_y zeros(1,5) -1 0; 0 1+Csi*Epsi -Kappa 0 -Kappa*SigmaN/(1+SigmaN) -Csi 0 -Eta zeros(1,2); ...
        0 Chi*(Theta-1)*Epsi 0 1 0 -Chi*(Theta-1) 0 -Chi zeros(1,2); 0 -Epsi zeros(1,2) 1 zeros(1,5); 1/Sigma 0 1 zeros(1,2) -1/Sigma -Gamma zeros(1,2) -1; ...
        zeros(3,1) eye(3) zeros(3,6); zeros(2,8) eye(2)];
    G1s=G1;
    CSIs=CSI;
    PIs=PI;
    % Here we get M1:
    M1=GetM1(G0,G1,CSI,PI,G0s,G1s,CSIs,PIs);
    Step=mean(diff(PHI_PIS));
    while M1==-9999
        phi_pis=phi_pis+Step;
        G0s=[1 (Rho-1)*phi_pis (Rho-1)*Phi_y zeros(1,5) -1 0; 0 1+Csi*Epsi -Kappa 0 -Kappa*SigmaN/(1+SigmaN) -Csi 0 -Eta zeros(1,2); ...
            0 Chi*(Theta-1)*Epsi 0 1 0 -Chi*(Theta-1) 0 -Chi zeros(1,2); 0 -Epsi zeros(1,2) 1 zeros(1,5); 1/Sigma 0 1 zeros(1,2) -1/Sigma -Gamma zeros(1,2) -1; ...
            zeros(3,1) eye(3) zeros(3,6); zeros(2,8) eye(2)];
        M1=GetM1(G0,G1,CSI,PI,G0s,G1s,CSIs,PIs);
    end
    [U,DD,V]=svd(PIstarx);
    [rDD,cDD]=size(DD);
    sDD=min([rDD cDD]');
    sDD=sDD-sum(diag(DD(1:sDD,1:sDD))==0);
    if size(V(:,sDD+1:size(V,2)),2)~=1
        MinusLogLikelihood=1.0e+100;
        return
    end
    G=real(Z1*(CSIstarc+PIstarc*(V(:,sDD+1:size(V,2))*M1-V(:,1:sDD)*MyInverse(DD(1:sDD,1:sDD))*U(:,1:sDD)'*CSIstarx)));
    VAR=diag([S_R S_pi S_y]');
    Q=G*VAR*G';
elseif INST==3
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % This is the solution for the case of determinacy--that is: uniqueness of equilibrium.
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    PIstar=Q*PI;
    L22=L(N-INST+1:N,N-INST+1:N);
    PIstarx=L22\PIstar(N-INST+1:N,:);
    %
    if det(PIstarx)==0
        MinusLogLikelihood=1.0e+100;
        return
    else
        CSIstar=Q*CSI;
        L11=L(1:N-INST,1:N-INST);
        O11=O(1:N-INST,1:N-INST);
        % O22=O(N-INST+1:N,N-INST+1:N);
        Z1=Z(:,1:N-INST);
        %
        PIstarc=L11\PIstar(1:N-INST,:);
        CSIstarc=L11\CSIstar(1:N-INST,:);
        %
        CSIstarx=L22\CSIstar(N-INST+1:N,:);
        %
        G=real(Z1*(CSIstarc-PIstarc*(PIstarx\CSIstarx))); % We kill off the imaginary parts because they are negligible: check this
        VAR=diag([S_R S_pi S_y]');
        Q=G*VAR*G';
    end
else
    MinusLogLikelihood=1.0e+100;
    return
end
F=real(Z1*(L11\O11)*Z1');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if any(abs(eig(F))>=1)==1
    MinusLogLikelihood=1.0e+100;
    return
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H=[eye(3) zeros(3,N-3)]';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial values for key variables:
s0=zeros(size(G0,1),1);
P0=eye(size(Q));
s=zeros(size(s0,1),T+1);
st=s;
s(:,1)=s0;
P=P0;
if det(H'*P*H)==0
    MinusLogLikelihood=1.0e+100;
    return
end
st(:,1)=s0;
Pt=P0;
%
Y=demean(Y);
%
L=zeros(T,1);
tt=1;
while tt<=T
    uhat=Y(tt,:)'-H'*s(:,tt);
    st(:,tt+1)=s(:,tt)+P*H*inv(H'*P*H)*uhat;
    Pt=P-P*H*(inv(H'*P*H))*H'*P;
    s(:,tt+1)=F*s(:,tt)+F*P*H*(inv(H'*P*H))*uhat;
    L(tt)=-0.5*log(det(H'*P*H))-0.5*(uhat'*(inv(H'*P*H))*uhat);
    P=Q+F*P*F'-F*P*H*(inv(H'*P*H))*H'*P*F';
    if det(H'*P*H)==0
        MinusLogLikelihood=1.0e+100;
        return
    end
    tt=tt+1;
end
if sum(abs(imag(L))>0)>0
    MinusLogLikelihood=1.0e+100;
else
    MinusLogLikelihood=-sum(L);
end


