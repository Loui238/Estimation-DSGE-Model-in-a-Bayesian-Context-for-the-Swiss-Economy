function [PDF,Grid]=PDFContour(X,Grid)
%
% Luca Benati
% Bank of England
% Monetary Assessment and Strategy Division
% August 2006
%
% function [PDF,Grid]=PDFContour(X,Grid)
% This program computes the contours of the PDFs for a given matrix X of
% distributions (typically, coming from Gibbs sampling, Metropolis-Hastings, 
% etc.) and a given matrix Grid of grids over which the distributions has 
% to be defined.
%
%                                             Input of the program is:
% X     = an RxC matrix
% Grid  = an RxC matrix
%                                             Output of the program is:
% PDF  = the contours of the PDFs
%
Ngrid=size(Grid,1);
X=sort(X);
[R,C]=size(X);
PDF=[ones(1,C); zeros(Ngrid-2,C); ones(1,C)];
for hh=1:C
    PDF(1,hh)=sum(X(:,hh)<Grid(2,hh));
    PDF(Ngrid,hh)=sum(X(:,hh)>=Grid(Ngrid-1,hh));
    for jj=2:size(Grid,1)-1
        PDF(jj,hh)=sum(X(:,hh)<Grid(jj+1,hh))-sum(X(:,hh)<Grid(jj,hh));
    end
end
DeltaGrid=mean(diff(Grid));
Grid=[Grid(1)-DeltaGrid; Grid; Grid(length(Grid))+DeltaGrid];
PDF=[zeros(1,C); PDF/sum(PDF); zeros(1,C)];









