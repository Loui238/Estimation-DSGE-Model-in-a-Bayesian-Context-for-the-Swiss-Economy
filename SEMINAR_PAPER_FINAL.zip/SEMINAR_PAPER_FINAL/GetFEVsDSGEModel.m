function FractionsOfFEV=GetFEVsDSGEModel(F,A0,H,Horizon);
NumberOfObservables=size(H,2);
[N,K]=size(A0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I: Computing the variance of the forecast error conditional on all shocks
VarianceForecastErrorAllShocks=zeros(NumberOfObservables,NumberOfObservables,Horizon+1);
% The 1-steap ahead the variance of the forecast error conditional on all shocks:
VarianceForecastErrorAllShocks(:,:,1)=H'*A0*A0'*H;
kk=2;
while kk<=Horizon+1
    % This is the expression on slide 14:
    VarianceForecastErrorAllShocks(:,:,kk)=VarianceForecastErrorAllShocks(:,:,kk-1)+H'*F^(kk-1)*A0*A0'*(F^(kk-1))'*H;
    kk=kk+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% II: Computing the variance of the forecast error conditional on individual shocks
VarianceForecastErrorIndividualShocks=zeros(NumberOfObservables,NumberOfObservables,Horizon+1,K);
%
Shock=1;
while Shock<=K
    % Here we define the covariance matrix of the structural shocks with
    % all the shocks other than the shock of interest being set to 0:
    E_Shock=zeros(K);
    E_Shock(Shock,Shock)=1;
    % The 1-step ahead variance of the forecast error conditional on the shock of interest:
    VarianceForecastErrorIndividualShocks(:,:,1,Shock)=H'*A0*E_Shock*A0'*H;
    kk=2;
    while kk<=Horizon+1
        % This is the expression on slide 18:
        VarianceForecastErrorIndividualShocks(:,:,kk,Shock)=VarianceForecastErrorIndividualShocks(:,:,kk-1,Shock)+H'*F^(kk-1)*A0*E_Shock*A0'*(F^(kk-1))'*H;
        kk=kk+1;
    end
    Shock=Shock+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% II.3: Computing the fractions of the variance of the forecast error due to individual shocks
FractionsOfFEV=zeros(Horizon+1,NumberOfObservables,K);
%
Series=1;
while Series<=NumberOfObservables
    Shock=1;
    while Shock<=K
        FEVAllShocks=squeeze(VarianceForecastErrorAllShocks(Series,Series,:));
        FEVIndividualShock=squeeze(VarianceForecastErrorIndividualShocks(Series,Series,:,Shock));
        FractionsOfFEV(:,Series,Shock)=FEVIndividualShock./FEVAllShocks;
        Shock=Shock+1;
    end
    Series=Series+1;
end





